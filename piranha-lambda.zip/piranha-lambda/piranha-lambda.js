const fetch = require('node-fetch');

exports.handler = async (event) => {
    console.log(event.FUNCTION);
    var URL = process.env.PIRANHA_SAP_PULL_REST+event.FUNCTION;
    console.log(URL);

    const res = fetch(URL);
    // const json = await res.json();
    return "Event triggered successfully";
};



// var req = require('request');

// exports.handler =  async function (event, context, callback) {
    
//    let output = null;
//     req.get(
//         { url: process.env.PIRANHA_SAP_PULL_REST , qs: {} },

//         (error, response, body) => {
//             if (error) {
//                 console.error('Error while triggering REST request ==> ', error.message);
//                 return;
//             }
//             output = body;
//             console.log(output);          
//         }
//     );
   
//     callback(null, output);
// };


const res = await fetch('https://swapi.co/api/people/1');
  const json = await res.json();
  return json;